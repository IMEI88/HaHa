# 青龙面板扫码小工具

## 简介
本程序仅限青龙面板2.0对接使用，可以使多用户自助使用以下功能：
* 扫码添加/更新cookie
* 删除cookie
* 查看单用户日志

## 说明
本程序仅供交流学习使用，请勿使用本程序进行商业行为。

## 安装
<https://ihuayu8.cn/ql-get-cookie.html>
详细教程请看此文章

## 相关链接
<https://github.com/whyour/qinglong>
